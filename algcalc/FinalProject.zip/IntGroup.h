#pragma once
class IntGroup     
{

};

